
/*
$(function(){
    $(".video").click(function(){
        var theModal = $(this).data("target");
        var videoSRC = $(this).attr("data-video");
        var videoSRCauto = videoSRC + "?modestbranding=1&rel=0&controls=0&showinfo=0&html5=1&autoplay=1";
        $(theModal + "iframe").attr("src", videoSRCauto);
        $(theModal + "button.close").click(function(){
            $(theModal + "iframe").attr("src", videoSRC);
        });
    });
});
*/
function click(){
    var src = document.getElementByTagName("iframe").getAttribute("src");
    var source = src + "?modestbranding=1&rel=0&controls=0&showinfo=0&html5=1&autoplay=1";
    document.getElementByTagName("iframe").setAttribute("src", source);
}


function close() {

    document.getElementByTagName("iframe").setAttribute("src", "http://www.youtube.com/embed/xMSGnGL8JU0");

}

var except = document.getElementById('videoModal');


except.addEventListener("click", function (event) {
    close();
    event.stopPropagation(); //this is important! If removed, you'll get both alerts
}, false);



$(document).on("click", "[data-toggle='lightbox']", function(event){
    event.preventDefault();
    $(this).ekkoLightbox();
});